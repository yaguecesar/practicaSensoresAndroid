<?php

function verPrincipal(){
?>
       <div id="page-wrapper" style="margin:0;background-image:url('img/back.jpeg');background-size:cover;">          
            <!-- /.row -->
            <div class="row" style="padding-top: 100px;min-height: 750px;/*-#0856de-padding-top: 50px;background-image: url(img/fondo.jpg);background-position: center;background-size:cover;*/">               
                <!-- empieza el cuerpo -->
                <div class="container" style="/*background: red;*/"> 

                   <div class="container">         
                          <div class="row" style="/*background: #00000080;*/">
                            <div class="col-lg-5"></div>
                            <div class="col-lg-4">
                              <h1>AVIVAR</h1>
                              <p>Gestion de usuarios</p>
                            </div>
                          </div>
                          <div class="separar-top" style="margin-top: 50px;"></div>
                        <form name="param" method="GET" action="index.php">
                          <div class="row" style="/*background: #00000080;*/">
                            <div class="col-lg-2"></div>
                            <div class="col-lg-5 my-auto">
                              <div class="header-content mx-auto">              
                                <button name="opc" value="introducir" class="boton" style="">Introducir Datos</button> 
                              </div>
                            </div>
                            <div class="col-lg-2 my-auto">
                                <!-- Demo image for screen mockup, you can put an image here, some HTML, an animation, video, or anything else! -->
                                <button name="opc" value="modificar" class="boton" style="">Modificar Datos</button>
                            </div>
                          </div>
                        </form>
                  </div>
                </div>
               <!--Fin cuerpo-->  
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

<style type="text/css"> 
  
  .boton:hover{
    background: none;color: white;
   
  }

  .boton{
     background: white;
    color: black;
     width: 200px;height: 200px;border-radius: 25px;font-size: 20px;
  }

</style>

<?php
}
?>