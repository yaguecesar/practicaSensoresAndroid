<?php


class GestorDB{
	private $conn;

	function __construct(){
		$root = realpath($_SERVER["DOCUMENT_ROOT"]);
		include "$root/plantilla/DBAccess.php";

		$this->conn = new mysqli($servername, $username, $password, $dbname);
		if ($this->conn->connect_error){	
			// No se ha podido establecer la conexión
			echo "Error conectando con la BBDD";
		}
	}

	function categorias(){
		$sql = "select * from categoria";
		$result = $this->conn->query($sql);

		while($row = $result->fetch_assoc()){
		      echo '<div class="checkbox"> <label><input type="checkbox" value="' . $row['idcategoria'] . '">' . $row['nombreCategoria'] .  '</label></div>';
	    }
	  }

   	function nombres(){
	  $sql = "select idPersona, nombrePersona from persona";
	  $result = $this->conn->query($sql);
	  //var_dump($result);

	  while($row = $result->fetch_assoc()){
	        echo '<option value="' . $row['nombrePersona'] . '">';
      }
	}

	function codigos(){
	  $sql = "select * from codigo";
	  $result = $this->conn->query($sql);

	  while($row = $result->fetch_assoc()){
	        echo '<option value="' . $row['siglas'] . '">' ;
	    }   
	}

	function buscarPersonaNombre(){
  		$sql = "select * from persona where nombrePersona like '" . $_POST["nombre"] . "';";

		  if($result = mysqli_query($this->conn, $sql)){
		      if(mysqli_num_rows($result) > 0){
		        tablaPersona($result);
		      }
		  }
}

	function insertarPersona(){

		//$this->$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		if (!isset($_POST['altaPersona'])) return -1;

		$statement = $this->conn->prepare("insert into persona (nombrePersona, DNI, sexo, edad, nacionalidad, docVinculado, telefono, anioIngreso, codigo) values(?, ?, ?, ?, ?, ?, ?, now(), ?);");
	  // Seleccionar el idPais correspondiente a la nacionalidad introducida
	  // Seleccionar el idCodigo correspondiente al código introducido
	  // Seleccionar el idActividad correspondiente a las actividades introducida
	  
	  $statement->bind_param("sssiissi", $nombrePersona, $dni, $sexo, $edad, $nacionalidad, $docVinculado, $telefono, $codigo);

	  
	  if (isset($_POST['nombre'])){
	  	$nombrePersona = $_POST['nombre'];
	  }

	
	  if (isset($_POST['dni'])){
	  	$dni = $_POST['dni'];
	  }

	  if (isset($_POST['edad'])){
	  	$edad = $_POST['edad'];
	  }
	  
	  if (isset($_POST['nacionalidad'])){
	  	$nacionalidad = intval($_POST['nacionalidad']);
	  }

	  $telefono = $_POST['telefono'];
	  $codigo = $_POST['codigo'];

	  if (isset($_POST['hombre'])){
	    $sexo = 'Hombre';
	  }else{
	    if (isset($_POST['mujer'])){
	      $sexo = 'Mujer';
	    }
	  }
	  if (isset($_POST['docVinculado'])){
	  	if (strcmp($_POST['docVinculado'], "") == 0 ){
	    $docVinculado = "null";
		  }else{
		    $docVinculado = $_POST['docVinculado'];
		  }
	  }

	  $numActividades = intval($this->conn->query("select count(*) from actividad")->fetch_assoc()['count(*)']);



	  //if (isset($_POST['ACT' . $var])){

	  //}

	  // Inicio transacción
	  //mysqli_autocommit($this->conn, false);
     // $this->conn->beginTransaction();

	  try{
	  		// Insertar persona
		  	$statement->execute();
		  	if (mysqli_stmt_affected_rows($statement) < 1){
		    	echo "error ----------- ";
		    	var_dump($_POST);
		    	return -1;
		  	}

		  $statement = $this->conn->prepare("insert into persona_actividad values (?,?)");
		  
		  $statement->bind_param("ii", $idPersona, $idActividad);
		  
		  for ($i = 1; $i <= $numActividades; $i++){
		  	if (isset($_POST['ACT' . $i])){
		  		// insertar en persona-actividad con el id de la persona y $i como id de actividad
		  		
		  		$selectIDquery = "select idPersona from persona order by idPersona desc limit 1";

		  		$idPersona = intval($this->conn->query($selectIDquery)->fetch_assoc()['idPersona']);
		  		$idActividad = $i;
		  		$statement->execute();
		  	}
		  }
		  
		  //$this->conn->commit();

	  }catch (PDOException $e){
    	//$this->conn->rollback();
    	echo "Error: " . $e->getMessage();
    	}
	  

	  // Insertar en tabla persona_actividad 
	  
    	//mysqli_autocommit($this->conn, true);
	  	// Fin transacción
	}



	function paises(){
	  $sql = "select * from pais";
	  $result = $this->conn->query($sql);

	  while($row = $result->fetch_assoc()){
	        echo '<option value="' . $row['idpais'] . '">' . $row['nombre'] . "</option>";
	    } 
	}

	function actividades(){

	 	$sql = "select * from actividad";
	  	$result = $this->conn->query($sql);

	  	while($row = $result->fetch_assoc()){
	        echo '<input type="checkbox" name="ACT' . $row['idActividad'].'" value="' . $row['idActividad'] . '">' . $row['nombreActividad'] . "<br>";
	    }
	}

	function cerrar(){
		$this->conn->close();
	}
}


?>