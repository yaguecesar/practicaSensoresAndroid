<?php
include_once "GestorDB.php";
$gestor = new GestorDB();

$gestor->insertarPersona();


?>