<?php

include "funcionesLogin.php";
include "funcionesModificar.php";
include "funcionesPrincipal.php";
include "funcionesVerDarAlta.php";
include "funcionesVisualizarDatos.php";
include "insertarPersona.php";


?>