<?php

if (isset($_GET['func_name'])){
  login();
}

function login(){
  session_start();//Para comprobar las posibles sesiones abiertas
 if($_SERVER['REQUEST_METHOD'] == 'POST'){
   if(isset($_POST['usuario'])){
    $_SESSION['id']  = $_POST["usuario"];    
   }
 }
header('Location: ../index.php');
}

function verContenido(){

  if(!isset($_SESSION["id"])){
      verLogin();
    }
    else{

      if($_SESSION['id'] == "admin"){            
        if($_SERVER['REQUEST_METHOD'] == 'GET'){
          if(!isset($_GET['opc']))
           verPrincipal();
          else{
             if($_GET['opc'] == 'introducir'){
              verDarAlta();
              }elseif($_GET['opc'] == 'modificar'){
               modificar();              
            }
          }

         }
      }elseif($_SESSION['id'] == "practicas"){
        verDarAlta();
      }else{
        verLogin();
      }

      //Metodo post para recibir el cierre de la sesión
      if(isset($_POST['cerrar'])){
        cerrarSesion();
    }

    }

}

function cerrarSesion(){
    session_destroy();
    header("Refresh:0");
}




function verLogin(){
?>

       <div id="page-wrapper" style="margin:0;background-image:url('img/fondo.jpg');background-size:cover;">          
            <!-- /.row -->
            <div class="row" style="padding-top: 100px;min-height: 750px;/*-#0856de-padding-top: 50px;background-image: url(img/fondo.jpg);background-position: center;background-size:cover;*/">               
                <!-- empieza el cuerpo -->
                <div class="container" style="/*background: red;*/"> 
                  <div class="row">
                      <div class="col-md-4 col-md-offset-4">
                          <div class="login-panel panel panel-default">
                              <div class="panel-heading">
                                  <h3 class="panel-title">Login</h3>
                                 <!-- <img src="img/logo calidad.png" width="100px">-->
                              </div>
                              <div class="panel-body">
                                  <form role="form" action="funciones/funcionesLogin.php?func_name=login" method="post">
                                      <fieldset>
                                          <div class="form-group">
                                              <input class="form-control" placeholder="Usuario" name="usuario" type="text" autofocus>
                                          </div>
                                          <div class="form-group">
                                              <input class="form-control" placeholder="Contraseña" name="password" type="password" value="">
                                          </div>
                                          <!-- Change this to a button or input when using this as a form -->
                                          <input class="btn btn-lg btn-success btn-block" type="submit" value="Login">
                                      </fieldset>
                                  </form>
                              </div>
                          </div>
                      </div>
                  </div>
                </div>
               <!--Fin cuerpo-->  
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

<?php
}

?>