<?php 
include_once "vista/header.inc.php";
include "vista/footer.inc.php";
include "funciones/funciones.inc.php";
session_start();//Para comprobar las posibles sesiones abiertas
verHeader();
verContenido();
verFooter();
?>