<?php

function verModificar(){
?>
       <div id="page-wrapper" style="margin:0;background-image:url('img/back.jpeg');background-size:cover;">          
            <!-- /.row -->
            <div class="row" style="padding-top: 100px;min-height: 750px;/*-#0856de-padding-top: 50px;background-image: url(img/fondo.jpg);background-position: center;background-size:cover;*/">               
                <!-- empieza el cuerpo -->
                <div class="container" style="/*background: red;*/"> 

                 <h1>MODIFICAR COMING SOON</h1>


                    </div>
               <!--Fin cuerpo-->  
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

<?php 
}
?>