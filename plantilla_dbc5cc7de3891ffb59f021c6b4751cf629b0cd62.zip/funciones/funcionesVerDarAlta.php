<?php

include "gestorDB.php";

$gestor = new GestorDB();


function verDarAlta(){
?>
  <div class="page-wrapper" style="margin: 0px; background-image: url('img/back.jpeg'); background-size: 100% 100%">
    <div class="row" style="padding-top: 100px, min-height: 750; ">
      <div class="container" >
       <div class="formulario" style="background: #8db3e2cc;margin-top: 50px;padding: 20px;">
                    
                    <form method="POST" action="funciones/insertarPersona.php">

                        <div class="row">
                            <div class="col-lg-2">
                                <input type="text" name="nombre" placeholder="nombre" list="listaNombres">
                                <datalist id="listaNombres">
                                <?php                                 
                                $gestor = new GestorDB();

                                $gestor->nombres(); ?>
                                </datalist>

                            </div> 
                            
                            <div class="col-lg-2">
                                 <input type="text" name="dni" placeholder="dni">
                            </div>
                            <div class="col-lg-2">
                                 <input type="text" name="docVinculado" placeholder="docVinculado">
                            </div> 
                            <div class="col-lg-2">
                                 <input type="number" name="edad" placeholder="edad">
                            </div>                          
                        </div>

                        <div class="row">
                            <div class="col-lg-2">
                                <input name="nacionalidad" placeholder="Nacionalidad" list="listaPaises">
                                <datalist id="listaPaises">
                                  <?php 
                                  $gestor = new GestorDB();
                                  $gestor->paises() ?>
                                </datalist>
                            </div> 
                            <div class="col-lg-2">
                                <label>sexo</label>
                                <div class="checkbox">
                                  <label><input type="checkbox" name="hombre" value="checked">Hombre</label>
                                </div>
                                <div class="checkbox">
                                  <label><input type="checkbox" name="mujer" value="checked">Mujer</label>
                                </div>
                            </div> 
                            <!--Posible modificación
                            <div class="col-lg-2">
                                <label>Continente</label>
                            </div>
                            -->
                            <div class="col-lg-2">
                                    <input type="number" name="telefono" placeholder="telefono">
                            </div>
                            <div class="col-lg-2">
                                    <input name="codigo" placeholder="codigo">
                            </div>
                            <div class="col-lg-5">
                                  <label>Categorías</label>
                                <?php 
                                $gestor = new GestorDB();
                                $gestor->categorias() ?>                  
                            </div>  
                            <div class="col-lg-2"> 
                                <?php 
                                    $gestor->actividades();
                                ?>
                            </div>                       
                        
                    </div>                                             
                    <div class="separar-top" style="margin-top: 50px;"></div>
                    <div class="row">                
                        <input type="submit" name="altaPersona"/>                        
                    </div>
                </form> <!--termina formulario-->            
              </div> <!--termina div formulario-->
            </div>
          </div>
        </div>

<?php

}
?>



