<?php 
function tablaPersona($result){
  echo "<table>";
      echo "<tr>";
            echo "<th>idPersona</th>";
            echo "<th>nombrePersona</th>";
            echo "<th>apellidos</th>";
            echo "<th>DNI</th>";
            echo "<th>sexo</th>";
            echo "<th>edad</th>";
            echo "<th>nacionalidad</th>";
            echo "<th>docVinculado</th>";
            echo "<th>telefono</th>";
            echo "<th>anioIngreso</th>";
            echo "<th>codigo</th>";
        echo "</tr>";

      while($row = mysqli_fetch_array($result)){
        filaPersona($row);
      }
      echo "</table>";
}

function filaPersona($row){
  echo "<tr>";
    echo "<td>" . $row['idPersona'] . "</td>";
    echo "<td>" . $row['nombrePersona'] . "</td>";
    echo "<td>" . $row['Apellidos'] . "</td>";
    echo "<td>" . $row['DNI'] . "</td>";
    echo "<td>" . $row['sexo'] . "</td>";
    echo "<td>" . $row['edad'] . "</td>";
    echo "<td>" . $row['nacionalidad'] . "</td>";
    echo "<td>" . $row['docVinculado'] . "</td>";
    echo "<td>" . $row['telefono'] . "</td>";
    echo "<td>" . $row['anioIngreso'] . "</td>";
    echo "<td>" . $row['codigo'] . "</td>";
  echo "</tr>";
}


?>