<?php 
function verHeader(){
?>
<!DOCTYPE html>
    <html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Horuelo</title>

        <!-- Bootstrap Core CSS -->
        <link href="vista/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="vista/metisMenu/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="vista/css/sb-admin-2.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="vista/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!--Favicon-->
        <link rel="shortcut icon" href="img/logo2.ico">
        <!--Color del tema version móvil-->
        <meta name="theme-color" content="#0856de" />
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesnt work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>

    <body>

        <div id="wrapper">

            <!-- Navigation -->
            <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
                <div class="navbar-header" style="height: 80px;">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="./"><img src="img/logo.png" style="width: 130px;margin-top: -25px;"></a>
                </div>
                <?php  if(isset($_SESSION["id"])){ ?>
                <form action="./" method="post" name="cerrar">
                    <ul class="nav navbar-top-links navbar-right">
                        <li class="">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="" >
                                 <i class="fa fa-sign-in"></i><input style="background: none;border:none;" type="submit" name="cerrar" value="Cerrar sesión" /> 
                            </a>                        
                        </li>
                    <!-- /.dropdown -->
                    </ul>
                </form>
                <!-- /.navbar-top-links --> 
                <?php }?>               
            </nav>

            <style type="text/css">
                .formulario form div div{
                    padding: 10px;
                } 

                .separarPaddingTop{
                    padding-top: 50px;
                }


            </style>
<?php
}
?>